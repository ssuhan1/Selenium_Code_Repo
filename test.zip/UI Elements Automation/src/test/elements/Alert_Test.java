package test.elements;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert_Test {
	
	static WebDriver driver;
	static String baseURL= "http://67.207.83.190:8080//";

	public static void main(String[] args) {
		
		// Initialize driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sadma\\Downloads\\ChromeDriver\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.get(baseURL);
	   
	    // Login to the dash board
	    driver.findElement(By.id("email")).sendKeys("ahmedsadman120@gmail.com");
	    driver.findElement(By.id("password")).sendKeys("3465EVALINEst@");
	    driver.findElement(By.xpath("//*[@id=\"signInModal\"]/div/div/div[2]/form/div[3]/button[2]")).click();
	    
	    //Login Assertion
	    String expectedText= driver.findElement(By.xpath("//*[@id=\"content\"]/div/div/div/h3")).getText();
	    String actualText= "Welcome To Test Automation";
	    if(expectedText.equals(actualText)) {
	    	System.out.println("Logged in successfully");
	    }else {
	    	System.out.println("Couldn't login successfully");
	    }
	   

	      //automate the alert button
	    driver.findElement(By.linkText("Alert")).click();
	    
	    //Alert page assertion
	    String expectedAlertText= driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div/div/h3")).getText();
	    String actualAlertText= "JavaScript Alerts";
	    if(expectedAlertText.equals(actualAlertText)) {
	    	System.out.println("Alert page appear");
	    }else {
	    	System.out.println("Alert page doesn't appear");
	    }
	    driver.findElement(By.id("alert")).click();
	    driver.switchTo().alert().accept();
	    
	    try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    driver.quit();
	    
		
		
	

	}

}
